apt install -y jq
apt-get install -y software-properties-common
apt install -y emacs
